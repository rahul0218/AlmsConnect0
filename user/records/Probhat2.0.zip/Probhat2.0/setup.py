from setuptools import setup

setup(
    name='Probhat2.0',
    version='2.0',
    packages=[''],
    url='http://localhost/Project8.1',
    license='',
    author='Tanmoy',
    author_email='tanmoypal25011994@gmail.com',
    description='This is Probhat The Web Assistant'
)
